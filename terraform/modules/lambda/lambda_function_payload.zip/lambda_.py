import os
from typing import Dict

import boto3

s3_client = boto3.client("s3")
ec2_client = boto3.client("ec2")

bucket_name = os.environ["BUCKET_NAME"]
file_name = os.environ["FILE_NAME"]

def lambda_handler(event: Dict, context) -> None:
    
    """
    AWS Lambda function handler
    """
    # script python
    return 0